package org.example.Model;

import org.example.Design.CalculatorInterface;

public class App
{
    public static void main( String[] args )
    {

        CalculatorInterface c= new CalculatorInterface();
    }
}
